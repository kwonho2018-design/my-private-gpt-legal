WORDAY OPEN LEARNING DATA / 워데이 공개 학습 데이터

Worday 2.1.0 (5), 2026-09-08
20,094 headwords, 13 recommended cumulative courses, 743 Days of 40 words.
The JSON data is a separately licensed component. CC BY-SA 4.0 applies to the adapted compilation; retain the original source notices in DATA-LICENSES.txt and per-entry source information. You may copy, modify, and redistribute it under these notices. No copy protection or encryption is applied. Application-only restrictions do not restrict these rights. This package contains no application code, user records, private account information, original DAY11 HTML, or source publications.

School-year placement is editorial and is not an official mandatory grade-specific list.
